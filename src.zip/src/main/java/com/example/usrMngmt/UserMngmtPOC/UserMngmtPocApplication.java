//https://www.codejava.net/frameworks/hibernate/hibernate-many-to-many-association-with-extra-columns-in-join-table-example
package com.example.usrMngmt.UserMngmtPOC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserMngmtPocApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserMngmtPocApplication.class, args);
	}

}
