package com.example.usrMngmt.UserMngmtPOC.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.usrMngmt.UserMngmtPOC.model.UserWorkReqTypeLL;

public interface UserWorkReqTypeLLRepo extends JpaRepository<UserWorkReqTypeLL,Long>{

}
